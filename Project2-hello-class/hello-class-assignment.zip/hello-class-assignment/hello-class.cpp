//hello class assignment
//CIS 1111

#include <iostream>

using namespace std;

int main()
{
    cout <<"  "<<endl;
    cout <<"Name: Erik Larson"<<endl;
    cout <<"  "<<endl;
    cout <<"Major: Software Development (maybe)"<<endl;
    cout <<"  "<<endl;
    cout <<"Total Credits: 9"<<endl;
    cout <<"  "<<endl;
    cout <<"Program Name: Hello Class"<<endl;
    cout <<"  "<<endl;
    cout <<"Program Description:"<<endl;
    cout <<"I believe this course will help me hone and expand my skills"<<endl;
    cout <<"and give me experience and knowledge that will be useful going forward"<<endl;
    cout <<"     "<<endl;
    //Visual Studio Community is not compatible with Ubuntu
    //but I am familiar with Visual Studio Code and know how
    //to add the right compiler so that it works correctly
    //I think
    //You'll be the judge of that, I'm still learning

    return 0;
}





